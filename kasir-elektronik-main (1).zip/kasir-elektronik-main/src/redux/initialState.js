export const initialStateLogin = {
  isLoggedIn: false,
  token: '',
  storeID: '',
  isLoading: false,
};
