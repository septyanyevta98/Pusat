export const BASE_URL = 'https://api-pe.visualprotech.com/employee';
