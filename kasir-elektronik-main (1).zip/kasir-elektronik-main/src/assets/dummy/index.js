import Banner from './Banner.png';
import Product1 from './Product1.png';
import Product2 from './Product2.png';
import Product3 from './Product3.png';
import Product4 from './Product4.png';
import Product5 from './Product5.png';
import Recommended from './Recommended.png';
export {Banner, Product1, Product2, Product3, Product4, Product5, Recommended};
