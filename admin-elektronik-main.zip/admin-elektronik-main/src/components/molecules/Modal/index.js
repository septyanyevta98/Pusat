import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import MLogout from './MLogout';
const Modal = () => {
  return (
    <View>
      <Text>Modal</Text>
    </View>
  );
};

export default Modal;

const styles = StyleSheet.create({});
