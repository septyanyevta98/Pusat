import Logo from './logo.png';

export {Logo};
