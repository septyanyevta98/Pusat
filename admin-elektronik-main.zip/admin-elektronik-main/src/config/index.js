// export const BASE_URL = 'https://pesona-solusindo.com/api/pusat/public/api';
// export const BASE_URL = 'https://api-pe.visualprotech.com/admin';
// export const BASE_URL = 'https://api-pe.visualprotech.com/employee';
export const BASE_URL = 'https://api.pesona-solusindo.com/admin';
