export const initialStateLogin = {
  isLoggedIn: false,
  token: '',
  isLoading: false,
};
