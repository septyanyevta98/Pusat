// export const BASE_URL = 'https://api-pe.visualprotech.com/employee';
export const BASE_URL = 'https://api.pesona-solusindo.com/employee';
