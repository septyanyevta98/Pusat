export const colors = {
  blue: '#40BFFF',
  blueDark: '#223263',
  gray: '#9098B1',
  border: '#d3d8e6',
  red: '#FB7181',
};
