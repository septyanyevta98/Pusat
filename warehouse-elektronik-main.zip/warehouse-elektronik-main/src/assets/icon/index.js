import AddAdmin from './AddAdmin.svg';
import AddAdminActive from './AddAdminActive.svg';
import Home from './Home.svg';
import HomeActive from './HomeActive.svg';
import Log from './Log.svg';
import LogActive from './LogActive.svg';
import User from './User.svg';
import Password from './Password.svg';

export {
  AddAdmin,
  AddAdminActive,
  Home,
  HomeActive,
  Log,
  LogActive,
  User,
  Password,
};
