import Logo from './Logo.png';
import Google from './Google.svg';
import Facebook from './Facebook.svg';

export {Logo, Google, Facebook};
