import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const EditProfile = ({navigation}) => {
  return (
    <View>
      <Text>Edit Profile</Text>
    </View>
  );
};

export default EditProfile;

const styles = StyleSheet.create({});
